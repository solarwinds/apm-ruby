require_relative '../digest'
