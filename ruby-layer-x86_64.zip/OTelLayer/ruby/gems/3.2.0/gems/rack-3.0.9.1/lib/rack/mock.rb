# frozen_string_literal: true

require_relative 'mock_request'
